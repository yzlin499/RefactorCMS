
--用于创建一个新的学期,如果创建成功,则返回一个新的学期的ID,如果创建失败则抛出错误
CREATE PROC dbo.F_CreateTerm(
	@TermName NVARCHAR(20),		--学期的可见名称
	@StartDate DATE=NULL		--本学期的开学日期
) AS BEGIN
	SET NOCOUNT ON
	IF @TermName IS NULL BEGIN
		RAISERROR(N'学期名不能为空',16,1);
		RETURN;
	END
	DECLARE @TID INTEGER
	SELECT @TID=TID FROM dbo.TermInfo WHERE TName=@TermName
	IF @TID IS NULL BEGIN
		INSERT dbo.TermInfo(TName,TStartDate)VALUES(@TermName,@StartDate)
		SET @TID=@@IDENTITY;
	END
	SELECT @TID AS New_ID
END
GO

