--此函数用于用户签到
CREATE PROC dbo.F_CheckIn(
	@VerifyCode VARCHAR(4),
	@BuildingFlag VARCHAR(32)
) AS BEGIN
	DECLARE @PID SMALLINT
	SELECT @PID=PID FROM dbo.VerifyCodeInfo WHERE VType=1 AND VCode=@VerifyCode AND VExpire>GETDATE()
	DECLARE @DTimeON TIME
	IF @PID IS NOT NULL BEGIN
		DECLARE @BID TINYINT
		SELECT @BID=BID FROM dbo.BuildingInfo WHERE BUUID=@BuildingFlag
		IF @BID IS NULL BEGIN
			RAISERROR (N'签到地点不存在',16,1);
			RETURN;
		END
		DECLARE @CKID BIGINT
		DECLARE @DDate DATE
		SELECT @DDate=GETDATE()
		SELECT @CKID=CKID,@DTimeON=DTimeON FROM dbo.CheckInfo WHERE DDate=@DDate AND BID=@BID AND PID=@PID AND DTimeOFF IS NULL
		IF @CKID IS NOT NULL BEGIN
			--签退
			DECLARE @DTimeOFF TIME
			SET @DTimeOFF=GETDATE();
			IF DATEDIFF(hh,@DTimeON,@DTimeOFF)>=6 BEGIN
				--签退加上标记,0x2为签退时间超过6小时
				UPDATE dbo.CheckInfo SET DFlag=(DFlag | 2 ) WHERE CKID=@CKID
			END
			
			UPDATE dbo.CheckInfo SET DTimeOFF=@DTimeOFF WHERE CKID=@CKID
			SELECT N'签退成功,值班时长:'+ LTRIM(STR(DATEDIFF(mm,@DTimeON,@DTimeOFF)))+N'分钟' AS Msg
		END ELSE BEGIN
			--签到
			SET @DTimeON=GETDATE()
			DECLARE @Flag TINYINT
			SET @Flag=0

			--对于是否是计划内值班进行判断,否则要进行标记
			DECLARE @StartDate DATE,@CurDate DATE
			SET @CurDate=GETDATE()
			SELECT @StartDate=TStartDate FROM dbo.GlobalInfo,dbo.TermInfo WHERE GName=N'CurTermID' AND TID=GValue
			IF @StartDate IS NULL BEGIN
				RAISERROR (N'本学期的开始日期还未填写,请通知管理员',16,1)
				RETURN;
			END
			DECLARE @ClWeek INT,@Week INT,@Time INT
			SET @ClWeek=DATEDIFF(dd,@StartDate,@CurDate);
			SET @Week=@ClWeek%7;
			SET @ClWeek=POWER(2,@ClWeek/7);

			SET @Time=DATEPART(hh,GETDATE())
			SET @Time=CASE WHEN @Time BETWEEN 7 AND 11 THEN 127 WHEN @Time BETWEEN 13 AND 17 THEN 960 WHEN @Time BETWEEN 18 AND 22 THEN 15360 ELSE 0 END



			IF NOT EXISTS(SELECT * FROM dbo.DutyInfo WHERE (DClWeek&@ClWeek)<>0 AND DWeek=@Week AND PID=@PID AND BID=@BID AND (DClTime&@Time)<>0) BEGIN
				--签到加上标记,0x1为签到信息与值班表不符
				SET @Flag=(@Flag | 1 )
			END

			INSERT dbo.CheckInfo(PID,DDate,DTimeON,DTimeOFF,BID,DFlag)VALUES(@PID,GETDATE(),@DTimeON,NULL,@BID,@Flag)
			SELECT N'签到成功,下班后要记得来签退哦' AS Msg
		END
	END ELSE BEGIN
		RAISERROR (N'验证码错误或已过期',16,1)
	END
    
    

END
GO

