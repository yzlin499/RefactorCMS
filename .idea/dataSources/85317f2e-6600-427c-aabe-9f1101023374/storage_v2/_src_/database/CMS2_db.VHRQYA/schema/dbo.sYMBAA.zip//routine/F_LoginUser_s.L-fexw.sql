
CREATE PROC dbo.F_LoginUser_s(		--利用已经绑定的信息,获取该信息绑定的
	@BindType TINYINT,				--ID的类型
	@BindValue NVARCHAR(50)			--查找的数据的值
) AS BEGIN
	SET NOCOUNT ON
	DECLARE @PID SMALLINT
	DECLARE @PCtrlLevel TINYINT
	DECLARE @PGroup TINYINT

	SELECT @PID=PersonInfo.PID,@PCtrlLevel=PCtrlLevel,@PGroup=PGroup FROM dbo.BindInfo,dbo.PersonInfo 
		WHERE BindInfo.PID=PersonInfo.PID AND @BindType=BDType AND @BindValue=BDValue
	IF @@ROWCOUNT=0 BEGIN
		RAISERROR(N'信息错误,无法找到对应的账户',16,1);
		RETURN;
	END ELSE BEGIN
		SELECT @PID AS PersonID,@PCtrlLevel AS PersonCtrlLevel,@PGroup as PersonGroup
	END
END
GO

