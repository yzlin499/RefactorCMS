CREATE PROC dbo.F_GenerateVerifyCode(
	@WechatID NVARCHAR(30)
) AS BEGIN
SET NOCOUNT ON
	DECLARE @PID SMALLINT
	SELECT @PID=PID FROM dbo.BindInfo WHERE BDType=1 AND BDValue=@WechatID

	IF @PID IS NOT NULL
	BEGIN
		DECLARE @VerifyCode INT
		SELECT @VerifyCode=FLOOR(RAND()*10000)
		WHILE @VerifyCode<1000
			SELECT @VerifyCode=FLOOR(RAND()*10000)
		
		IF NOT EXISTS(SELECT * FROM dbo.VerifyCodeInfo WHERE PID=@PID AND VType=1)
		BEGIN
			INSERT dbo.VerifyCodeInfo(PID,VType,VCode,VExpire) VALUES(
				@PID,
			    1,
			    @VerifyCode,
			    DATEADD(ss,10,GETDATE()) -- VExpire - datetime
			   )
		END ELSE BEGIN
			UPDATE dbo.VerifyCodeInfo SET VCode=@VerifyCode,VExpire=DATEADD(ss,10,GETDATE()) WHERE PID=@PID AND VType=1
		END
		SELECT @VerifyCode
	END
    ELSE
		RAISERROR(N'找不到对应的用户',16,1)
END
GO

